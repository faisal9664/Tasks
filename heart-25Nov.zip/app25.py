import os
import pickle
import numpy as np
import streamlit as st

st.set_page_config(page_title="Heart Disease Predictor", layout="centered")

@st.cache_resource
def load_model():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    candidates = [
        os.path.join(base_dir, "heart_model.pkl"),
        os.path.join(base_dir, "..", "heart_model.pkl"),
        "heart_model.pkl",
    ]
    for path in candidates:
        if os.path.exists(path):
            with open(path, "rb") as f:
                return pickle.load(f)
    raise FileNotFoundError("heart_model.pkl not found. Run Heart-25Nov.ipynb first to generate it.")

@st.cache_data(ttl=300)
def predict_heart(values):
    bundle = load_model()
    arr = np.array(values, dtype=np.float64)
    scaled = (arr - bundle["mean"]) / bundle["std"]
    z = float(np.dot(scaled, bundle["weights"]) + bundle["bias"])
    prob = float(1.0 / (1.0 + np.exp(-np.clip(z, -500, 500))))
    return int(prob >= 0.5), prob

st.title("Heart Disease Risk Predictor")

col1, col2 = st.columns(2)
with col1:
    age = st.number_input("Age", 20, 100, 54)
    sex = st.selectbox("Sex", ["Male", "Female"])
    cp = st.selectbox("Chest Pain Type (cp)", [0, 1, 2, 3])
    trestbps = st.number_input("Resting BP (trestbps)", 80, 220, 130)
    chol = st.number_input("Cholesterol (chol)", 100, 600, 240)
    fbs = st.selectbox("Fasting Blood Sugar > 120 (fbs)", [0, 1])
    restecg = st.selectbox("Resting ECG (restecg)", [0, 1, 2])

with col2:
    thalach = st.number_input("Max Heart Rate (thalach)", 60, 220, 150)
    exang = st.selectbox("Exercise Induced Angina (exang)", [0, 1])
    oldpeak = st.number_input("ST Depression (oldpeak)", 0.0, 7.0, 1.0, step=0.1)
    slope = st.selectbox("Slope", [0, 1, 2])
    ca = st.selectbox("Major Vessels (ca)", [0, 1, 2, 3, 4])
    thal = st.selectbox("Thal", [0, 1, 2, 3])

if st.button("Predict"):
    sex_num = 1 if sex == "Male" else 0
    inputs = (age, sex_num, cp, trestbps, chol, fbs, restecg, thalach, exang, oldpeak, slope, ca, thal)
    pred, prob = predict_heart(inputs)
    label = "Heart Disease Detected" if pred == 1 else "No Heart Disease"
    st.subheader(label)
    st.metric("Risk Probability", f"{prob:.2%}")